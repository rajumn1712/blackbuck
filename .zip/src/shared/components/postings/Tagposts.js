import React from 'react';

const TagPost = ()=>{
    return(
        <div>
            <h1>Tag page Coming soon...</h1>
        </div>
    )
}

export default TagPost;