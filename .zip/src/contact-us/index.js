import React, { Component } from 'react';

class Contactus extends Component {

    componentDidMount() {

    }

    render() {
        return (
            <div>
                <p>Contactus works</p>
            </div>
        )
    }
}

export default Contactus;